#include "item.h"

Item::Item(Vec pos): Position{pos} {}

Item::~Item() {}

Vec Item::getPos() {return Position;}
